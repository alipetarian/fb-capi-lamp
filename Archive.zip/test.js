{
  "data": [
    {
      "event_name": "Purchase",
      "event_time": 1660139125,
      "action_source": "website",
      "event_source_url": "https://alipetarian.com",
      "event_id": "12345",
      "user_data": {
        "client_ip_address": "192.168.8.1",
        "client_user_agent": "Mozilla",
        "fbc": "fb.1.23434",
        "fbp": "fb.1.343434.23434"
      },
      "custom_data": {
        "currency": "USD",
        "value": "142.52"
      }
    }
  ]
}