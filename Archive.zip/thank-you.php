<?php
error_reporting(E_ALL);

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Thank You Page</title>

  <?php
  include('./fb_capi.php');
 include('./fb_purchase.php');
  ?>
</head>
<body>
  <h3>This is thank you page</h3>
<?php
//  include('./fb_page_view.php');

 echo "<br/><br/><hr/>";


?>
</body>
</html>